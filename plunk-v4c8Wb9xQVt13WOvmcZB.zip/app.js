var app = angular.module('myApp', ['ngRoute']);

// configuration to achieve route
app.config(function($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "users.html",
      controller: "usersController"

    })
    .when("/view/:id", {
      templateUrl: "view.html",
      controller: "viewController"

    })
});

// controller to view list of users
app.controller('usersController', function($scope, $http) {
  // service to get users list
  $http.get("https://jsonplaceholder.typicode.com/users")
    .then(function(response) {
      $scope.users = response.data;
    });
});

// controller to display user details
app.controller('viewController', function($scope, $http, $routeParams) {
  $scope.userId = $routeParams.id;

  // service to get user details list
  $http.get("https://jsonplaceholder.typicode.com/todos?userId=" + $routeParams.id + "")
    .then(function(response) {
      $scope.userDetails = response.data;
    });

  $scope.myVar1 = true;
  $scope.myVar = true;
  // function to add 
  $scope.addUserDetail = function(id) {
    // service to add new user detail
    $http.post("https://jsonplaceholder.typicode.com/todos", {
        title: $scope.title,
        completed: $scope.state,
        userId: id
      })
      .success(function(data, status, headers, config) {
        $scope.myVar = false;
        $scope.message = "Data saved";
      })
      .error(function(data, status, headers, config) {
        $scope.myVar1 = false;
        $scope.message = "Data not saved";
      });
  }
  
  // function to delete 
  $scope.delete = function(index) {
    $scope.userDetails.splice(index,1)
  }
});